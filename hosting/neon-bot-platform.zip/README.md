# Neon Bot Platform

Architecture:
- `panel/`: public Render web panel. Upload ZIP, detect Python entrypoint, create a run job.
- `runner/`: private Docker runner intended for a VPS. It polls the panel for jobs and runs approved uploads in isolated containers.

Important:
- Do NOT expose the runner API to the public Internet.
- Add authentication before making the panel public.
- This starter is intended for your own/authorized bot projects, not an anonymous public code-execution service.
- Render's filesystem is ephemeral, so the panel stores uploaded ZIPs only for the current service instance in this starter. For production, connect object storage/database.

## Panel on Render
Deploy the `panel` directory as a Python web service.
Build:
`pip install -r requirements.txt`
Start:
`uvicorn app:app --host 0.0.0.0 --port $PORT`

Set environment variables:
- `RUNNER_SECRET`: a long random secret
- `RUNNER_URL`: private URL reachable only by your runner

## Runner on VPS
Install Docker. Inside `runner/`:
`pip install -r requirements.txt`
Set:
- `PANEL_URL`
- `RUNNER_SECRET`
Then:
`python runner.py`

The runner polls for jobs and launches them with Docker limits.
