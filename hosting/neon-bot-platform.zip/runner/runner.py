import os,time,requests,subprocess,json,tempfile,shutil
PANEL=os.environ["PANEL_URL"].rstrip("/")
SECRET=os.environ["RUNNER_SECRET"]
INTERVAL=int(os.getenv("POLL_SECONDS","5"))

def headers():return {"X-Runner-Secret":SECRET}
def main():
    while True:
        try:
            r=requests.get(PANEL+"/internal/job",headers=headers(),timeout=15)
            job=r.json()
            if job:
                pid=job["id"]
                # The runner is private and only intended for authorized projects.
                # Run the uploaded project in a resource-limited Docker container.
                source=job["path"]
                name="neonbot_"+pid
                subprocess.run(["docker","rm","-f",name],capture_output=True,text=True)
                Path=os.path.join(source,".Dockerfile")
                open(Path,"w").write('FROM python:3.12-slim\nWORKDIR /bot\nCOPY . /bot\nRUN pip install --no-cache-dir -r requirements.txt || true\nCMD ["python", "'+job["entry"]+'"]\n')
                build=subprocess.run(["docker","build","-t",name,source],capture_output=True,text=True,timeout=180)
                if build.returncode:
                    requests.post(PANEL+f"/internal/status/{pid}",headers=headers(),json={"status":"ERROR"},timeout=15)
                else:
                    run=subprocess.run([
                        "docker","run","-d","--name",name,"--restart","unless-stopped",
                        "--memory","512m","--cpus","1","--pids-limit","256",
                        "--security-opt","no-new-privileges:true","--cap-drop","ALL",name
                    ],capture_output=True,text=True,timeout=30)
                    st="ONLINE" if run.returncode==0 else "ERROR"
                    requests.post(PANEL+f"/internal/status/{pid}",headers=headers(),json={"status":st},timeout=15)
                try: os.remove(os.path.join(source,".Dockerfile"))
                except: pass
        except Exception as e:
            print("runner:",e)
        time.sleep(INTERVAL)

if __name__=="__main__":main()
