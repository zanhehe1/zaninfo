import os, json, uuid, zipfile, shutil
from pathlib import Path
from fastapi import FastAPI, UploadFile, File, Header, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

BASE=Path("/tmp/neon-panel")
BASE.mkdir(parents=True,exist_ok=True)
app=FastAPI(title="Neon Bot Hosting")
SECRET=os.getenv("RUNNER_SECRET","change-me")
PRIORITY=["start.py","main.py","bot.py","app.py","run.py"]

def auth(value):
    if value != SECRET: raise HTTPException(401,"Unauthorized")

def safe_extract(z,d):
    base=d.resolve()
    for i in z.infolist():
        p=(d/i.filename).resolve()
        if p!=base and not str(p).startswith(str(base)+"/"): raise HTTPException(400,"Unsafe ZIP")
    z.extractall(d)

def detect(root):
    for n in PRIORITY:
        if (root/n).is_file(): return n
    best=None
    for p in root.rglob("*.py"):
        if "__pycache__" in p.parts: continue
        try:t=p.read_text(errors="ignore")
        except:continue
        s=(100 if "__name__" in t and "__main__" in t else 0)+(15 if "telebot" in t else 0)
        if p.name in PRIORITY:s+=50
        if best is None or s>best[0]:best=(s,str(p.relative_to(root)))
    return best[1] if best and best[0] else None

def meta(pid):
    p=BASE/p
    if not p.exists():raise HTTPException(404,"Not found")
    return json.loads((p/"meta.json").read_text())

@app.get("/")
def home():return FileResponse("static/index.html")

@app.post("/api/upload")
async def upload(file:UploadFile=File(...)):
    if not file.filename.lower().endswith(".zip"):raise HTTPException(400,"ZIP only")
    pid=uuid.uuid4().hex[:12];p=BASE/pid;code=p/"code";code.mkdir(parents=True)
    with zipfile.ZipFile(await save(file,p/"upload.zip")) as z:
        if len(z.infolist())>10000:raise HTTPException(400,"Too many files")
        safe_extract(z,code)
    entry=detect(code)
    if not entry:
        shutil.rmtree(p,ignore_errors=True);raise HTTPException(400,"No Python entrypoint found")
    m={"id":pid,"name":Path(file.filename).stem[:60],"entry":entry,
       "requirements":(code/"requirements.txt").is_file(),"status":"OFFLINE"}
    (p/"meta.json").write_text(json.dumps(m))
    return m

async def save(f,path):
    with path.open("wb") as o:
        while c:=await f.read(1024*1024):
            o.write(c)
            if path.stat().st_size>200*1024*1024: raise HTTPException(413,"ZIP too large")
    return path

@app.get("/api/projects")
def projects():return [json.loads((p/"meta.json").read_text()) for p in BASE.iterdir() if (p/"meta.json").exists()]

@app.post("/api/projects/{pid}/run")
def queue(pid:str):
    p=BASE/pid;m=meta(pid)
    (p/"job.json").write_text(json.dumps({"id":pid,"action":"run"}))
    m["status"]="QUEUED";(p/"meta.json").write_text(json.dumps(m))
    return {"ok":True,"status":"QUEUED","message":"Job queued for the private runner"}

@app.get("/internal/job")
def job(x_runner_secret:str=Header(default="")):
    auth(x_runner_secret)
    for p in BASE.iterdir():
        j=p/"job.json"
        if j.exists():
            m=json.loads((p/"meta.json").read_text())
            return {"id":m["id"],"entry":m["entry"],"path":str(p/"code")}
    return {}

@app.post("/internal/status/{pid}")
def status(pid:str,x_runner_secret:str=Header(default=""),payload:dict={}):
    auth(x_runner_secret);m=meta(pid);m["status"]=payload.get("status","OFFLINE")
    (BASE/pid/"meta.json").write_text(json.dumps(m));return {"ok":True}

app.mount("/static",StaticFiles(directory="static"),name="static")
